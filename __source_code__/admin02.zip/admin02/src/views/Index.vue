<template>
  <div>
    <el-button type="primary">主要按钮</el-button><br/>
    <el-button type="primary">主要按钮</el-button><br/>
    <el-button type="primary">主要按钮</el-button><br/>
    <el-button type="primary">主要按钮</el-button><br/>
    <el-button type="primary">主要按钮</el-button><br/>
    <el-button type="primary">主要按钮</el-button><br/>
    <el-button type="primary">主要按钮</el-button><br/>
    <el-button type="primary">主要按钮</el-button><br/>
    <el-button type="primary">主要按钮</el-button><br/>
    <el-button type="primary">主要按钮</el-button><br/>
    <el-button type="primary">主要按钮</el-button><br/>
    <el-button type="primary">主要按钮</el-button><br/>
    <el-button type="primary">主要按钮</el-button><br/>
    <el-button type="primary">主要按钮</el-button><br/>
    <el-button type="primary">主要按钮</el-button><br/>
    <el-button type="primary">主要按钮</el-button><br/>
    <el-button type="primary">主要按钮</el-button><br/>
    <el-button type="primary">主要按钮</el-button><br/>
    <el-button type="primary">主要按钮</el-button><br/>
    <el-button type="primary">主要按钮</el-button><br/>
    <el-button type="primary">主要按钮</el-button><br/>
  </div>
</template>

<script setup>
</script>

<style scoped>
  div {
    color: aquamarine;
  }
</style>
<template>
  <!--路径匹配到的组件，将会展示在这里-->
  <router-view></router-view>
</template>

<script>
export default {
  name: 'App'
}
</script>
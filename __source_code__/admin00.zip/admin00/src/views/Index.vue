<template>
  <div><el-button type="primary">主要按钮</el-button></div>
  <el-icon><Aim /></el-icon>
</template>

<script setup>
</script>

<style scoped>
  div {
    color: aquamarine;
  }
</style>